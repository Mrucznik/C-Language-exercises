//main.c

#include <stdio.h>

int main(void)
{
	int a, b;
	printf("Podaj przedzial <k, l> z ktorego wyznaczyc liczby fibbonaciego: ");
	scanf("%d%d", &a, &b);

	int i = 0;
	int fib[2] = {0, 1};
	while(fib[1] <= b)
	{
		int tmp = fib[1];
		fib[1] += fib[0];
		fib[0] = tmp;

		if (fib[1] <= b)
			printf("%d\n", fib[1]);
	}
	return 0;
}

